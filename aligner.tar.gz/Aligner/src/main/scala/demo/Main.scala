package demo

import geotrellis.raster._
import geotrellis.spark._

object Main {
  def helloSentence = "Hello GeoTrellis"

  def main(args: Array[String]): Unit = {
    println(helloSentence)
  }
}
